# Tasks for Today - TSA3

A Laravel task management application for IT0049 Technical Summative Assessment 3, developed by **Mason Andrei Cedo**.

The application has four pages: a Welcome page showing today's tasks, a complete Task List ordered by date, a Profile page showing the single saved user, and a static About page identifying the developer.

## Requirements

- PHP 8.3 or newer with Laravel's required extensions
- Composer 2
- SQLite extensions: `pdo_sqlite` and `sqlite3`

There is no frontend build step. The project uses Blade and plain CSS, so Node.js and npm are not needed.

## Run locally

Extract the project into its own folder. Open a terminal in the folder containing `artisan` and `composer.json`, then run:

```sh
composer install
composer run setup
php artisan serve
```

Open **http://127.0.0.1:8000** in your browser. Keep the terminal running while using the website.

Setup copies `.env.example` to `.env` when needed, generates the application key, creates `database/database.sqlite`, and runs the migrations and seeders. Use a fresh SQLite database for this project.

Run setup once on a fresh installation. It generates a new application key each time. If a PHP extension is missing, use `php --ini` to find the terminal's configuration file and `php -m` to check enabled extensions.

## Pages

| Route | Page | Behavior |
| --- | --- | --- |
| `/` | Welcome | Displays only tasks whose `task_date` is today, including pending and completed tasks. |
| `/tasks` | Task List | Displays every task, ordered by `task_date` from earliest to latest, then by ID. |
| `/profile` | Profile | Displays the single saved user's full name, username, and email. |
| `/about` | About | Identifies the developer and describes the project without querying the database. |

All four pages share a Blade layout and navigation. The application displays records; task editing and sign-in are outside this assessment's listed requirements.

## Database schema

| Table | Fields |
| --- | --- |
| `tasks` | `id`, `title`, `status` (default `pending`), `task_date`, `created_at`, `updated_at` |
| `users` | `id`, `username` (unique), `full_name`, `email`, `created_at`, `updated_at` |

Migrations create the tables. `Task` and `User` are Eloquent models. The generated SQLite file is excluded from Git because the migrations and seeders recreate the database.

## Sample records

The seeder creates **nine tasks across three dates**:

- Three tasks for yesterday
- Three tasks for today
- Three tasks for tomorrow

It also creates **exactly one user** on a fresh database:

- Full name: Mason Andrei Cedo
- Username: Mason Andrei
- Email: masonandrei07@gmail.com

The username includes a space, as specified for this project. Developer information is stored in `config/developer.php` and used by both the user seeder and the static About page.

The sample task dates are calculated when seeding. They are not fixed calendar dates. To refresh the nine sample tasks around the current day, run:

```sh
php artisan db:seed
```

Reseeding updates the existing sample tasks and profile instead of duplicating them. It resets the sample task dates and statuses but does not delete extra records that you have added yourself.

## How today's filtering works

`TaskController::today` uses the `forToday` local scope on the Task model. The scope runs `whereDate('task_date', today())`, so yesterday's and tomorrow's tasks are excluded. The Task List uses a separate Eloquent query without that date filter.

The application uses **Asia/Shanghai** time by default. Change `APP_TIMEZONE` in `.env` if needed. After changing configuration, run:

```sh
php artisan config:clear
```

As the calendar day changes, the Welcome page automatically selects the new day's matching records. Existing task dates stay unchanged until the records are updated or the sample data is reseeded.

## Main project files

```text
app/Http/Controllers/
  TaskController.php
  ProfileController.php
  PageController.php
app/Models/
  Task.php
  User.php
config/developer.php
database/migrations/
  0001_01_01_000000_create_users_table.php
  2026_11_21_000001_create_tasks_table.php
database/seeders/
  DatabaseSeeder.php
  TaskSeeder.php
  UserSeeder.php
resources/views/
  layouts/app.blade.php
  welcome.blade.php
  tasks/index.blade.php
  profile.blade.php
  about.blade.php
public/css/style.css
routes/web.php
tests/Feature/
```

Controllers retrieve records through Eloquent. Blade views loop over the records and use escaped output for task titles and profile information. The shared layout contains the header, navigation, and footer.

## Inspect and test

```sh
php artisan route:list --except-vendor
php artisan migrate:status
php artisan test
```

The tests cover navigation, today's task filtering, local midnight, task ordering, all nine seeded records, database updates, profile retrieval, the static About page, empty results, escaped text, the required schema, the default status, unique usernames, and repeated seeding.

Tests use an in-memory SQLite database. The GitHub Actions workflow also runs them on pushes and pull requests.

## Screenshots

If screenshots are requested, capture all four pages after running the seeders. The Welcome page should show three tasks for today. The Task List should show nine tasks across three dates. Profile and About should display the developer details above.

The worksheet's listed submission requirements are a source repository and a working application link; it does not explicitly require screenshots. This package is prepared for local use, with no public deployment included.

## Upload to GitHub

Create a new empty repository. Upload the **contents of the `tasks-for-today-tsa3` folder**, including `.env.example`, `.gitignore`, and `.github/workflows/tests.yml`. Keep `artisan` and `composer.json` at the repository root.

Do not upload only the ZIP file. Do not upload your generated `.env`, SQLite database, or `vendor` folder. A separate SQL export is unnecessary because the migrations and seeders are included.

For Git, replace the URL below with your new repository's URL:

```sh
git init
git add .
git commit -m "Add Tasks for Today Laravel application"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

## References

- [Laravel Eloquent models and query scopes](https://laravel.com/docs/13.x/eloquent#query-scopes)
- [Laravel migrations](https://laravel.com/docs/13.x/migrations)
- [Laravel database seeding](https://laravel.com/docs/13.x/seeding)
