<?php

namespace Tests\Feature;

use App\Models\Task;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class DatabaseSeederTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->travelTo(Carbon::parse('2026-11-21 12:00:00', 'Asia/Shanghai'));
    }

    public function test_seeders_create_nine_tasks_across_three_dates_and_exactly_one_user(): void
    {
        $this->seed();
        $this->seed();

        $this->assertDatabaseCount('tasks', 9);
        $this->assertDatabaseCount('users', 1);
        $this->assertSame(3, Task::distinct()->count('task_date'));
        $this->assertSame(3, Task::forToday()->count());
        $this->assertSame(3, Task::whereDate('task_date', today()->subDay())->count());
        $this->assertSame(3, Task::whereDate('task_date', today()->addDay())->count());
        $this->assertDatabaseHas('users', [
            'username' => 'Mason Andrei',
            'full_name' => 'Mason Andrei Cedo',
            'email' => 'masonandrei07@gmail.com',
        ]);
    }

    public function test_reseeding_on_another_day_refreshes_sample_dates_without_duplicates(): void
    {
        $this->seed();
        $this->travelTo(Carbon::parse('2026-11-25 12:00:00', 'Asia/Shanghai'));
        $this->seed();

        $this->assertDatabaseCount('tasks', 9);
        $this->assertDatabaseCount('users', 1);
        $this->assertSame(3, Task::forToday()->count());
        $this->assertSame(0, Task::whereDate('task_date', '2026-11-20')->count());
    }

    public function test_schema_matches_the_required_fields_and_status_defaults_to_pending(): void
    {
        $taskColumns = Schema::getColumnListing('tasks');
        $userColumns = Schema::getColumnListing('users');
        sort($taskColumns);
        sort($userColumns);

        $this->assertSame(['created_at', 'id', 'status', 'task_date', 'title', 'updated_at'], $taskColumns);
        $this->assertSame(['created_at', 'email', 'full_name', 'id', 'updated_at', 'username'], $userColumns);

        $task = Task::create(['title' => 'Task without an explicit status', 'task_date' => today()]);
        $this->assertSame('pending', $task->refresh()->status);
    }

    public function test_usernames_are_unique(): void
    {
        User::factory()->create(['username' => 'same.username']);

        $this->expectException(QueryException::class);
        User::factory()->create(['username' => 'same.username']);
    }
}
