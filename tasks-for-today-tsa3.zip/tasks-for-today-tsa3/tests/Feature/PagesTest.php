<?php

namespace Tests\Feature;

use App\Models\Task;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Tests\TestCase;

class PagesTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->travelTo(Carbon::parse('2026-11-21 12:00:00', 'Asia/Shanghai'));
    }

    public function test_all_four_pages_have_working_navigation(): void
    {
        $this->seed();
        $pages = ['/' => 'Welcome', '/tasks' => 'Task List', '/profile' => 'Profile', '/about' => 'About'];

        foreach ($pages as $path => $title) {
            $response = $this->get($path);
            $response->assertOk()->assertSee('<title>'.$title.' | Tasks for Today</title>', false);

            foreach (array_keys($pages) as $destination) {
                $response->assertSee('href="'.url($destination).'"', false);
            }
        }
    }

    public function test_welcome_only_displays_todays_tasks_regardless_of_status(): void
    {
        Task::factory()->create(['title' => 'A task from yesterday', 'task_date' => today()->subDay()]);
        Task::factory()->create(['title' => 'Todays pending task', 'status' => 'pending']);
        Task::factory()->create(['title' => 'Todays completed task', 'status' => 'completed']);
        Task::factory()->create(['title' => 'A task for tomorrow', 'task_date' => today()->addDay()]);

        $this->get('/')->assertOk()
            ->assertSee('Todays pending task')
            ->assertSee('Todays completed task')
            ->assertDontSee('A task from yesterday')
            ->assertDontSee('A task for tomorrow')
            ->assertViewHas('tasks', fn ($tasks) => $tasks->count() === 2);
    }

    public function test_welcome_has_an_empty_state_when_only_other_dates_have_tasks(): void
    {
        Task::factory()->create(['title' => 'Old task', 'task_date' => today()->subDay()]);
        Task::factory()->create(['title' => 'Future task', 'task_date' => today()->addDay()]);

        $this->get('/')->assertOk()->assertSee('No tasks scheduled for today.')->assertDontSee('Old task')->assertDontSee('Future task');
    }

    public function test_task_list_includes_every_task_in_date_order(): void
    {
        Task::factory()->create(['title' => 'Future task', 'task_date' => today()->addDay()]);
        Task::factory()->create(['title' => 'Current task', 'task_date' => today()]);
        Task::factory()->create(['title' => 'Past task', 'status' => 'completed', 'task_date' => today()->subDay()]);
        Task::factory()->create(['title' => 'Second current task', 'task_date' => today()]);

        $response = $this->get('/tasks');
        $response->assertOk()->assertSeeInOrder(['Past task', 'Current task', 'Second current task', 'Future task'])->assertSee('4 records');
        $this->assertSame(4, substr_count($response->getContent(), '<th scope="row">'));
    }

    public function test_task_list_displays_all_nine_seeded_records(): void
    {
        $this->seed();
        $response = $this->get('/tasks');
        $response->assertOk()->assertSee('9 records');
        $this->assertSame(9, substr_count($response->getContent(), '<th scope="row">'));
    }

    public function test_database_changes_are_reflected_in_both_task_views(): void
    {
        $task = Task::factory()->create(['title' => 'Original task']);
        $this->get('/')->assertOk()->assertSee('Original task');

        $task->update(['title' => 'Rescheduled task', 'task_date' => today()->addDay()]);
        $this->get('/')->assertOk()->assertDontSee('Original task')->assertDontSee('Rescheduled task');
        $this->get('/tasks')->assertOk()->assertSee('Rescheduled task')->assertDontSee('Original task');
    }

    public function test_profile_displays_the_single_saved_user_and_database_updates(): void
    {
        $this->seed();
        $this->assertDatabaseCount('users', 1);
        $this->get('/profile')->assertOk()->assertSee('Mason Andrei Cedo')->assertSee('Mason Andrei')->assertSee('masonandrei07@gmail.com');

        User::first()->update(['full_name' => 'Updated Profile Name', 'email' => 'updated@example.com']);
        $this->get('/profile')->assertOk()->assertSee('Updated Profile Name')->assertSee('updated@example.com');
    }

    public function test_empty_task_list_and_profile_have_clear_messages(): void
    {
        $this->get('/tasks')->assertOk()->assertSee('No tasks found.')->assertSee('0 records');
        $this->get('/profile')->assertOk()->assertSee('No profile information is available.');
    }

    public function test_about_identifies_the_developer_without_querying_the_database(): void
    {
        $connection = config('database.default');
        config(['database.default' => 'unavailable']);

        try {
            $this->get('/about')->assertOk()->assertSee('Mason Andrei Cedo')->assertSee('masonandrei07@gmail.com')->assertSee('TSA3');
        } finally {
            config(['database.default' => $connection]);
        }
    }

    public function test_saved_task_titles_and_profile_names_are_escaped(): void
    {
        $text = '<script>alert("test")</script>';
        Task::factory()->create(['title' => $text]);
        User::factory()->create(['full_name' => $text]);

        foreach (['/', '/tasks', '/profile'] as $path) {
            $this->get($path)->assertOk()->assertSee(e($text), false)->assertDontSee($text, false);
        }
    }

    public function test_today_changes_at_midnight_in_the_application_timezone(): void
    {
        $this->assertSame('Asia/Shanghai', config('app.timezone'));
        Task::factory()->create(['title' => 'November 21 task', 'task_date' => '2026-11-21']);
        Task::factory()->create(['title' => 'November 22 task', 'task_date' => '2026-11-22']);

        $this->travelTo(Carbon::parse('2026-11-21 15:59:59', 'UTC'));
        $this->get('/')->assertOk()->assertSee('November 21 task')->assertDontSee('November 22 task');

        $this->travelTo(Carbon::parse('2026-11-21 16:00:00', 'UTC'));
        $this->get('/')->assertOk()->assertSee('November 22 task')->assertDontSee('November 21 task');
    }
}
