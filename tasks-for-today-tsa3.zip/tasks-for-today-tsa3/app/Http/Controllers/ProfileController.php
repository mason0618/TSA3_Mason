<?php

namespace App\Http\Controllers;

use App\Models\User;

class ProfileController extends Controller
{
    public function index()
    {
        $user = User::orderBy('id')->first();

        return view('profile', compact('user'));
    }
}
