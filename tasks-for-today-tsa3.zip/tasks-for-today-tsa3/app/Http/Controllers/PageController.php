<?php

namespace App\Http\Controllers;

class PageController extends Controller
{
    public function about()
    {
        $developer = config('developer');

        return view('about', compact('developer'));
    }
}
