<?php

namespace App\Http\Controllers;

use App\Models\Task;

class TaskController extends Controller
{
    public function today()
    {
        $tasks = Task::forToday()->orderBy('id')->get();
        $today = today();

        return view('welcome', compact('tasks', 'today'));
    }

    public function index()
    {
        $tasks = Task::orderBy('task_date')->orderBy('id')->get();

        return view('tasks.index', compact('tasks'));
    }
}
