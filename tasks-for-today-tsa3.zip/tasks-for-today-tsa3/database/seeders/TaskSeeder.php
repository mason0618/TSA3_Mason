<?php

namespace Database\Seeders;

use App\Models\Task;
use Illuminate\Database\Seeder;

class TaskSeeder extends Seeder
{
    public function run(): void
    {
        $today = today();
        $tasks = [
            ['title' => 'Review Laravel routing notes', 'status' => 'completed', 'task_date' => $today->copy()->subDay()],
            ['title' => 'Outline the database tables', 'status' => 'completed', 'task_date' => $today->copy()->subDay()],
            ['title' => 'Check the project requirements', 'status' => 'completed', 'task_date' => $today->copy()->subDay()],
            ['title' => 'Practice Eloquent queries', 'status' => 'pending', 'task_date' => $today->copy()],
            ['title' => 'Review the task list page', 'status' => 'pending', 'task_date' => $today->copy()],
            ['title' => 'Update project documentation', 'status' => 'completed', 'task_date' => $today->copy()],
            ['title' => 'Test the application navigation', 'status' => 'pending', 'task_date' => $today->copy()->addDay()],
            ['title' => 'Prepare project screenshots', 'status' => 'pending', 'task_date' => $today->copy()->addDay()],
            ['title' => 'Review the final submission', 'status' => 'pending', 'task_date' => $today->copy()->addDay()],
        ];

        foreach ($tasks as $task) {
            Task::updateOrCreate(['title' => $task['title']], $task);
        }
    }
}
