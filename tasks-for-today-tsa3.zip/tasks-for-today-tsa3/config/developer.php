<?php

return [
    'full_name' => 'Mason Andrei Cedo',
    'username' => 'Mason Andrei',
    'email' => 'masonandrei07@gmail.com',
];
