@extends('layouts.app')

@section('title', 'Welcome')

@section('content')
    <section class="page-heading welcome-heading">
        <div>
            <p class="eyebrow">Welcome</p>
            <h1>Your tasks for today.</h1>
            <p class="lead">Here is your plan for {{ $today->format('l, F j, Y') }}.</p>
        </div>
        <div class="date-card" aria-label="{{ $today->format('F j, Y') }}">
            <span>{{ $today->format('M Y') }}</span>
            <strong>{{ $today->format('d') }}</strong>
            <span>{{ $today->format('l') }}</span>
        </div>
    </section>

    <section class="summary-grid" aria-label="Today's task summary">
        <div class="summary-card"><span>Scheduled today</span><strong>{{ $tasks->count() }}</strong></div>
        <div class="summary-card"><span>Pending</span><strong>{{ $tasks->where('status', 'pending')->count() }}</strong></div>
        <div class="summary-card"><span>Completed</span><strong>{{ $tasks->where('status', 'completed')->count() }}</strong></div>
    </section>

    <section class="panel" aria-labelledby="today-heading">
        <div class="panel-heading">
            <h2 id="today-heading">Today's tasks</h2>
            <a class="text-link" href="{{ route('tasks.index') }}">View full task list <span aria-hidden="true">&rarr;</span></a>
        </div>

        <ul class="today-list">
            @foreach ($tasks as $task)
                <li>
                    <span class="task-marker {{ $task->status === 'completed' ? 'marker-completed' : '' }}" aria-hidden="true"></span>
                    <div class="task-copy">
                        <h3>{{ $task->title }}</h3>
                        <p>Scheduled for {{ $task->task_date->format('F j, Y') }}</p>
                    </div>
                    <span class="status {{ $task->status === 'completed' ? 'status-completed' : 'status-pending' }}">{{ ucfirst($task->status) }}</span>
                </li>
            @endforeach
        </ul>

        @if ($tasks->isEmpty())
            <div class="empty-state">
                <h3>No tasks scheduled for today.</h3>
                <p>You can still browse your other tasks in the full task list.</p>
            </div>
        @endif
    </section>
@endsection
