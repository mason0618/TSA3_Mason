<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A simple daily task planner by Mason Andrei Cedo.">
    <title>@yield('title', 'Welcome') | Tasks for Today</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>
<body>
    <a class="skip-link" href="#main-content">Skip to content</a>
    <header class="site-header">
        <div class="container header-content">
            <a class="brand" href="{{ route('welcome') }}">
                <span class="brand-mark" aria-hidden="true">T</span>
                <span>Tasks for Today</span>
            </a>
            <nav aria-label="Main navigation">
                <a href="{{ route('welcome') }}" @if(request()->routeIs('welcome')) aria-current="page" @endif>Welcome</a>
                <a href="{{ route('tasks.index') }}" @if(request()->routeIs('tasks.index')) aria-current="page" @endif>Task List</a>
                <a href="{{ route('profile') }}" @if(request()->routeIs('profile')) aria-current="page" @endif>Profile</a>
                <a href="{{ route('about') }}" @if(request()->routeIs('about')) aria-current="page" @endif>About</a>
            </nav>
        </div>
    </header>

    <main id="main-content" class="container">
        @yield('content')
    </main>

    <footer class="site-footer">
        <div class="container footer-content">
            <span>Tasks for Today</span>
            <span>IT0049 &middot; TSA3</span>
        </div>
    </footer>
</body>
</html>
