@extends('layouts.app')

@section('title', 'Task List')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Your schedule</p>
        <h1>Task List</h1>
        <p class="lead">All of your tasks, from the earliest date to the latest.</p>
    </section>

    <section class="panel" aria-labelledby="all-tasks-heading">
        <div class="panel-heading">
            <h2 id="all-tasks-heading">All tasks</h2>
            <span class="record-count">{{ $tasks->count() }} records</span>
        </div>
        <div class="table-scroll" tabindex="0" role="region" aria-label="All tasks table, scroll horizontally on small screens">
            <table>
                <caption class="sr-only">Every saved task, ordered by task date</caption>
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Task title</th>
                        <th scope="col">Task date</th>
                        <th scope="col">Status</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($tasks as $task)
                        <tr class="{{ $task->task_date->isToday() ? 'task-today' : '' }}">
                            <td class="task-id">T{{ str_pad($task->id, 3, '0', STR_PAD_LEFT) }}</td>
                            <th scope="row">{{ $task->title }}</th>
                            <td class="task-date">
                                {{ $task->task_date->format('M j, Y') }}
                                @if ($task->task_date->isToday()) <span class="today-label">Today</span> @endif
                            </td>
                            <td><span class="status {{ $task->status === 'completed' ? 'status-completed' : 'status-pending' }}">{{ ucfirst($task->status) }}</span></td>
                        </tr>
                    @endforeach

                    @if ($tasks->isEmpty())
                        <tr><td colspan="4" class="empty-cell">No tasks found.</td></tr>
                    @endif
                </tbody>
            </table>
        </div>
    </section>
@endsection
