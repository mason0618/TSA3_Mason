@extends('layouts.app')

@section('title', 'Profile')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">A little about you</p>
        <h1>Profile</h1>
        <p class="lead">Your personal information for Tasks for Today.</p>
    </section>

    @if ($user)
        <section class="profile-card" aria-labelledby="profile-name">
            <div class="profile-intro">
                <p class="eyebrow">Personal profile</p>
                <h2 id="profile-name">{{ $user->full_name }}</h2>
                <p>Tasks for Today account</p>
            </div>
            <dl class="profile-details">
                <div><dt>Full name</dt><dd>{{ $user->full_name }}</dd></div>
                <div><dt>Username</dt><dd>{{ $user->username }}</dd></div>
                <div><dt>Email address</dt><dd>{{ $user->email }}</dd></div>
            </dl>
        </section>
    @else
        <section class="panel empty-state">
            <h2>No profile information is available.</h2>
        </section>
    @endif
@endsection
