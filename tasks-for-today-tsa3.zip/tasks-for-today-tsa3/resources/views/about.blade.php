@extends('layouts.app')

@section('title', 'About')

@section('content')
    <section class="page-heading">
        <p class="eyebrow">Behind the project</p>
        <h1>About Tasks for Today</h1>
        <p class="lead">A simple way to see what needs your attention each day.</p>
    </section>

    <div class="about-grid">
        <article class="about-copy">
            <h2>One day at a time</h2>
            <p>Tasks for Today is a small task management system developed by {{ $developer['full_name'] }} for IT0049, Technical Summative Assessment 3.</p>
            <p>The Welcome page focuses on tasks scheduled for the current day. The Task List keeps every task available in date order, while the Profile page displays the user's information.</p>
            <p>The application uses Laravel, Eloquent models, and Blade templates to retrieve and display records from a database.</p>
            <a class="button" href="{{ route('welcome') }}">Back to today's tasks <span aria-hidden="true">&rarr;</span></a>
        </article>
        <aside class="developer-card" aria-labelledby="developer-heading">
            <p class="eyebrow">Developed by</p>
            <h2 id="developer-heading">{{ $developer['full_name'] }}</h2>
            <dl>
                <div><dt>Username</dt><dd>{{ $developer['username'] }}</dd></div>
                <div><dt>Email address</dt><dd>{{ $developer['email'] }}</dd></div>
                <div><dt>Course</dt><dd>IT0049 &mdash; Web System Technologies</dd></div>
                <div><dt>Assessment</dt><dd>TSA3 &mdash; Tasks for Today Management System</dd></div>
            </dl>
        </aside>
    </div>
@endsection
